var someFunc = function() {
  console.log('some func a');
};

function someFunc() {
  console.log('some func b');
}
