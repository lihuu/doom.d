'use strict';

function doSomeStuff() {
    alert('we did it!');
}
