# Tests

Like, yes, we have some! :)

## ERT-based tests

See `el-get-tests.el` in this directory.  You can run ERT-based tests by:

    test/run-ert.sh

To run the tests with GUI window for debugging, you can use:

    test/run-ert-interactive.sh

## Old issue reproducers

See the test/issues directory.
