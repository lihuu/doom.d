global_var = 1

local function test(arg)
    local var2
    return var2
end
