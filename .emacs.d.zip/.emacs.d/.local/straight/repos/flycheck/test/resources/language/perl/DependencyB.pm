package DependencyB;

use parent Exporter;

@EXPORT = qw($dependency_b);

our $dependency_b = 'bar';

1;
