#[cfg(test)]
#[macro_use]
extern crate lazy_static;

mod tests {
  #[test]
  fn it_works() {
    let foo = 0;
  }
}
