<?php

/**
 * Test the famous T_PAAMAYIM_NEKUDOTAYIM
 * Taken from http://stackoverflow.com/q/2248612/355252
 */

list($aDoor, size)  = split('_', $_POST['price']);

?>