def foo(x: str) -> int:
    return x
