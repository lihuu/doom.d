fn main() { let foo_main = 0; }

#[test]
fn test() { let foo_main_test = 0; }
