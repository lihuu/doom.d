fn main() { let foo_bench_a = 0; }

#[test]
fn test() { let foo_bench_a_test = 0; }
