#[test]
fn foo() { let foo_test_a_test = 0; }

fn foo_test_a() {}
