// A simple syntax error in Go

package main

func ta ta() {
}