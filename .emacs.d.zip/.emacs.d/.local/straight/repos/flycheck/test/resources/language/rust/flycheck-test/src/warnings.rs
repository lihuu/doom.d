// A warning for an unused variable

fn main() {
    let x = true;
}
