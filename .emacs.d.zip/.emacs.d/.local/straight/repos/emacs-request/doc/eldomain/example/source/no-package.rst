Example usage without specifying package
========================================

.. el:variable:: unknown/variable-example

   Documenting variable without specifying package...

.. el:macro:: unknown/macro-example

   Documenting face without specifying package...

.. el:function:: unknown/function-example

   Documenting function without specifying package...
